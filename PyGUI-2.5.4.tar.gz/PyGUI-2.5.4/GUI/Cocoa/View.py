#
#		Python GUI - Views - PyObjC
#

from GUI import export
from GUI.GViews import View as GView

class View(GView):

    _ns_scrollable = False

export(View)
