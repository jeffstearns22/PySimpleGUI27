#
#   Python GUI - Views - Gtk
#

from GUI import export
from GUI.GViews import View

export(View)
