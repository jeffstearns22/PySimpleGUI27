#
#   PyGUI - Edit command handling - Gtk
#

from GUI import export
from GUI.GEditCmdHandlers import EditCmdHandler

export(EditCmdHandler)
