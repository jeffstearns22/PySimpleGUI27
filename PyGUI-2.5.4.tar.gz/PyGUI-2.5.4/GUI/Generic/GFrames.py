#
#		Python GUI - Frames - Generic
#

from GUI import Container

class Frame(Container):
    """A Frame is a general-purpose instantiable subclass of Container."""

    _default_size = (100, 100)
