.. _basics.broadcasting:

************
Broadcasting
************

.. seealso::
    :class:`numpy.broadcast`

    :ref:`array-broadcasting-in-numpy`
        An introduction to the concepts discussed here

.. automodule:: numpy.doc.broadcasting
